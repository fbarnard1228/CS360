import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.Calendar;


class AppointmentServiceTest {

    private AppointmentService appointmentService;
    
    @Before
    public void setUp() {
        appointmentService = new AppointmentService();
    }
    
    @Test
    void testAddAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	@SuppressWarnings("unused")
			Appointment appointment = new Appointment("A1234567890", LocalDate.of(2024, Calendar.JUNE, 23), "This appointment is too long.");
        	appointmentService.addAppointment(appointment);
        });
    }
    
    @Test
    void testDeleteAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	@SuppressWarnings("unused")
			Appointment appointment = new Appointment("A1234567890", LocalDate.of(2024, Calendar.JUNE, 23), "This appointment is too long.");
        	appointmentService.deleteAppointment("A1234567890");
        });
    }

}
