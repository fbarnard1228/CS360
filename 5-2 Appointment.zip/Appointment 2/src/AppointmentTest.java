
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Calendar;

import static org.junit.jupiter.api.Assertions.assertTrue;


class AppointmentTest {

    @Test
    void testAppointment() {
        Appointment appointment = new Appointment("A12345", LocalDate.of(2024, Calendar.JUNE, 23), "I have a lot of appointments.");
        assertTrue(appointment.getAppointmentId().equals("A12345"));
        assertTrue(appointment.getAppointmentDate().equals(LocalDate.of(2024, Calendar.JUNE, 23)));
        assertTrue(appointment.getDescription().equals("I have a lot of appointments."));

    }

    @Test
    void testAppointmentIdToLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A1234567890", LocalDate.of(2024, Calendar.JUNE, 23), "This appointment is too long.");
        });
    }

    @Test
    void testAppointmentIdNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, LocalDate.of(2024, Calendar.JUNE, 23), "This appointment is too null.");
        });
    }
    
    @Test
    void testDateInThePast() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A12345", LocalDate.of(2023, Calendar.JUNE, 26), "This appointment is in the past.");
        });
    }

    @Test
    void testDateNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A12345", null, "This appointment date is null.");
        });
    }
    
    @Test
    void testAppointmentDescriptionToLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A12345", LocalDate.of(2024, Calendar.JUNE, 23), "This appointment description is very long and many people would not bother to read the whole thing and just skip over some parts");
        });
    }

    @Test
    void testAppointmentDescriptionNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A12345", LocalDate.of(2024, Calendar.JUNE, 23), null);
        });
    }
    
}
